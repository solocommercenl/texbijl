def calculate_monthly_payment_with_remaining_debt(principal, annual_interest_rate, loan_duration_months, desired_remaining_debt):
    """
    Calculates the monthly payment for a financial lease, aiming for a specific remaining debt at the end of the loan term.
    
    Parameters:
    - principal: The total loan amount.
    - annual_interest_rate: The annual interest rate as a decimal (e.g., 10% as 0.1).
    - loan_duration_months: The total number of months for the loan.
    - desired_remaining_debt: The desired remaining debt at the end of the loan term.
    
    Returns:
    The monthly payment amount.
    """
    # Convert annual interest rate to monthly
    monthly_interest_rate = annual_interest_rate / 12

    # First, calculate the present value of the desired remaining debt at the end of the loan term
    present_value_of_remaining_debt = desired_remaining_debt / ((1 + monthly_interest_rate) ** loan_duration_months)
    
    # Adjust the principal by subtracting the present value of the desired remaining debt
    adjusted_principal = principal - present_value_of_remaining_debt

    # Calculate monthly payment on the adjusted principal
    monthly_payment = adjusted_principal * (monthly_interest_rate / (1 - (1 + monthly_interest_rate) ** (-loan_duration_months)))
    
    return monthly_payment

# Example usage
principal = 12250  # The loan amount
annual_interest_rate = 0.1  # Annual interest rate (e.g., 10% as 0.1)
loan_duration_months = 72  # Loan duration in months
desired_remaining_debt = 2352  # Desired remaining debt at the end of the loan term
# 20% of the final price coming from the final_price script (principal)


monthly_payment = calculate_monthly_payment_with_remaining_debt(principal, annual_interest_rate, loan_duration_months, desired_remaining_debt)

# Print the monthly payment
print(f"The monthly payment is: {monthly_payment:.2f}")
