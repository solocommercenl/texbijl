extrasdict = {
    "Air conditioning": "Air conditioning",
    "Armrest": "Middenarmsteun",
    "Automatic climate control, 2 zones":"Climate control 2 zones",
    "Cruise control": "Cruise control",
    "Electric tailgate": "Elektrische achterklep",
    "Electrical side mirrors": "Elektrisch verstelbare buitenspiegels",
    "Electrically adjustable seats": "Elektrisch verstelbare stoelen",
    "Electrically heated windshield": "Electrische Voorruitverwarming",
    "Heated steering wheel": "Stuurwielverwarming",
    "Hill Holder": "Hill-hold control",
    "Leather seats": "Lederen bekleding",
    "Leather steering wheel": "Lederen stuurwiel",
    "Light sensor": "Lichtsensor",
    "Lumbar support": "Lendensteun",
    "Multi-function steering wheel": "Multifunctioneel stuurwiel",
    "Navigation system": "Navigatiesysteem",
    "Park Distance Control": "Parkeerhulp",
    "Parking assist system camera": "Parkeerhulp met camera",
    "Parking assist system sensors front": "Parkeersensoren voor",
    "Parking assist system sensors rear": "Parkeersensoren achter",
    "Power windows": "Elektrische ramen",
    "Rain sensor": "Regensensor",
    "Seat heating": "Stoelverwarming",
    "Split rear seats": "Achterbank neerklapbaar (in delen)",
    "Start-stop system": "Start-stop systeem",
    "Tinted windows": "Getinte ramen",
    "Android Auto": "Android Auto",
    "Apple CarPlay": "Apple CarPlay",
    "Bluetooth": "Bluetooth",
    "Digital cockpit": "Volledig digitaal instrumentarium",
    "Digital radio": "DAB+ radio",
    "Hands-free equipment": "Hands free kit",
    "Integrated music streaming": "Muziek streaming",
    "MP3": "MP3",
    "On-board computer": "Boordcomputer",
    "Radio": "Radio",
    "Sound system": "Multimediasysteem",
    "USB": "Usb aansluiting(en)",
    "WLAN / WiFi hotspot": "Wifi hotspot",
    "Alloy wheels": "Lichtmetalen velgen",
    "Ambient lighting": "Sfeerverlichting",
    "Automatically dimming interior mirror": "Automatisch dimmende binnenspiegel",
    "Electronic parking brake": "Elektrische handrem",
    "Emergency tyre repair kit": "Banden reparatieset",
    "Shift paddles": "Schakelflippers",
    "Spoiler": "Spoiler",
    "Sport package": "Sport-pakket",
    "Sport seats": "Sportstoelen",
    "Summer tyres": "Zomerbanden",
    "Touch screen": "Touchscreen",
    "Voice Control": "Spraakbediening",
    "Winter package": "Winterpakket",
    "ABS": "ABS",
    "Bi-Xenon headlights": "Bi-Xenon koplampen",
    "Central door lock": "Centrale vergendeling",
    "entral door lock with remote control": "Centrale vergendeling met afstandbediening",
    "Daytime running lights": "Dagrijverlichting",
    "Distance warning system": "Afstandwaarschuwingssysteem",
    "Driver drowsiness detection": "Slaperigheidswaarschuwing",
    "Driver-side airbag": "Bestuurder zij airbag",
    "Electronic stability control": "ESP",
    "Emergency brake assistant": "Brake assist",
    "Emergency system": "Noodoproepsysteem",
    "Full-LED headlights": "Led verlichting",
    "Fog lights": "mistlampen",
    "Head airbag": "Hoofd airbag",
    "High beam assist": "Grootlicht assistent",
    "Immobilizer": "Startonderbreker",
    "Isofix": "Isofix",
    "LED Daytime Running Lights": "Led dagrijverlichting",
    "LED Headlights": "Led verlichting",
    "Lane departure warning system": "Lane assist",
    "Passenger-side airbag": "passagier zij airbag",
    "Power steering": "Stuurbekrachtiging",
    "Rear airbag": "Achter airbags",
    "Side airbag": "Zij aibags",
    "Speed limit control system": "Snelheidsbegrenzer",
    "Tire pressure monitoring system": "Bandenspanningscontrole",
    "Traction control": "Traction control",
    "Traffic sign recognition": "Verkeersbord herkenning",
    "Xenon headlights": "Xenon koplamoen",
    "360° camera": "360 camera",
    "Automatic climate control": "Climate control",
    "Keyless central door lock": "Keyless entry",
    "Induction charging for smartphones": "Draadloze telefoonlader",
    "Alloy wheels (20)": "20 inch lichtmetalen velgen",   # might need some corecting key was a copy paste from csv
    "Cargo barrier": "Bagageruimte-afscheiding",
    "E10-enabled": "E10-geschikt",
    "Sport suspension": "Sportonderstel",
    "Adaptive Cruise Control": "Adaptive Cruise Control",
    "Blind spot monitor": "Dodehoek detectie",
    "Glare-free high beam headlights": "Adaptieve grootlichtassistent",
    "CD player": "CD Speler",
    "Alarm system": "Alarm systeem",
    "Alloy wheels (17)": "20 inch lichtmetalen velgen",  # might need some corecting key was a copy paste from csv
    "Heads-up display": "Heads-up display",
    "Seat ventilation": "stoelventilatie",
    "Smoker's package": "Rokers pakket",
    "Adaptive headlights": "Adaptieve koplampen",
    "Automatic climate control, 3 zones": "Climate control 3 zones", # might need some corecting key was a copy paste from csv
    "Panorama roof": "Panoramadak",
    "Sunroof": "Open dak",
    "Roof rack": "Dakrek",
    "Trailer hitch": "Trekhaak",
    "Catalytic Converter": "Katalysator",
    "Winter tyres": "Winterbanden",
    "Parking assist system self-steering": "Automatisch parkeren",
    "Alloy wheels (19)": "19 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Auxiliary heating": "Standkachel",
    "Alloy wheels (18)": "18 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Headlight washer system": "Koplampreinigingssysteem",
    "Ski bag": "Skiluik",
    "Fold flat passenger seat": "Neerklapbare passagiersstoel",
    "Emergency tyre": "Noodwiel",
    "All season tyres": "All season banden",
    "Electric backseat adjustment": "Elektrische achterbankverstelling",
    "Television": "Televisie",
    "Night view assist": "Night vision assist",
    "Sliding door right": "Schuifdeur rechts",
    "Spare tyre": "reservewiel",
    "Steel wheels": "Stalen velgen",
    "Sliding door left": "Schuifdeur links",
    "Automatic climate control, 4 zones": "Climate control 4 zones", # might need some corecting key was a copy paste from csv
    "Massage seats": "Massage stoelen",
    "Laser headlights": "Laser koplampen",
    "Alloy wheels (21)": "21 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Alloy wheels (16)": "16 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Range extender": "Range extender",
    "Air suspension": "Luchtvering",
    "Sliding door": "Schuifdeur",
    "Tuned car": "Getuned",
    "Handicapped enabled": "Gehandicapten geschikt",
    "Wind deflector": "Windscherm",
    "Alloy wheels (14)": "14  inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Alloy wheels (15)": "15 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Biodiesel conversion": "Biodiesel conversie",
    "Awning": "Luifel",
    "Alloy wheels (22)": "22 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Right hand drive": "Rechtsgestuurd",
    "Alloy wheels (13)": "13 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Alloy wheels (11)": "11 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Alloy wheels (23)": "23 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Alloy wheels (10)": "10 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Divider": "Tussenschot",
    "Double cabin": "Dubbele cabine",
    "Tail-lift": "Laadklep",
    "Differential lock": "Sperdifferentieel",
    "Alloy wheels (24)": "24 inch lichtmetalen velgen", # might need some corecting key was a copy paste from csv
    "Disc brake": "Schijf rem",
    "Sleeping berth": "Slaapplaats",
}




















