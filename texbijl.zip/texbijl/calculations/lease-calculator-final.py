def calculate_monthly_payment_with_remaining_debt(final_price, down_payment, annual_interest_rate, loan_duration_months,
                                                  desired_remaining_debt):
    """
    Calculates the monthly payment for a financial lease, aiming for a specific remaining debt at the end of the loan term.
    
    Parameters:
    - final_price: The price we get from the oter calculations and wgich is shown on website
    - down_payment: The initial payment made upfront, reducing the financed amount.
    - annual_interest_rate: The annual interest rate as a decimal (e.g., 10% as 0.1).
    - loan_duration_months: The total number of months for the loan.
    - desired_remaining_debt: The desired remaining debt at the end of the loan term.
    
    Returns:
    The monthly payment amount.
    """
    # Principal is now calculated as final_price minus down_payment
    principal = final_price - down_payment

    # Convert annual interest rate to monthly
    monthly_interest_rate = annual_interest_rate / 12

    # First, calculate the present value of the desired remaining debt at the end of the loan term
    present_value_of_remaining_debt = desired_remaining_debt / ((1 + monthly_interest_rate) ** loan_duration_months)

    # Adjust the principal by subtracting the present value of the desired remaining debt
    adjusted_principal = principal - present_value_of_remaining_debt

    # Calculate monthly payment on the adjusted principal
    monthly_payment = adjusted_principal * (
                monthly_interest_rate / (1 - (1 + monthly_interest_rate) ** (-loan_duration_months)))

    return monthly_payment


# Example usage
final_price = 12250  # This is the finalprice calculated from the other script
down_payment = 1225  # This should be set to 10% of final price initial but value v=can be changed by customer on website
annual_interest_rate = 0.1  # Annual interest rate (e.g., 10% as 0.1)  this we have to set in admin panel
loan_duration_months = 72  # This should be set to months initial but can be changed by customer on the website
desired_remaining_debt = 2450  # This should be set to 20% of final price initial but value v=can be changed by customer on website

monthly_payment = calculate_monthly_payment_with_remaining_debt(final_price, down_payment, annual_interest_rate,
                                                                loan_duration_months, desired_remaining_debt)

# Print the monthly payment
print(f"The monthly payment is: {monthly_payment:.2f}")
