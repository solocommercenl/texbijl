# Defining the original_price parameter with a static value
# Note: This value has to be pulled from a MongoDB database later
original_price = 60000

# Adding bpm_rate parameter
bpm_rate = 2000  # Note: This value will come from another function/script in the future

# Tax rates
de_tax = 1.19  # Tax rate for Germany
nl_tax = 1.21  # Tax rate for the Netherlands

# Updated margin values with specified percentages
margin_one = 0.10  # 10%
margin_two = 0.08  # 8%
margin_three = 0.07  # 7%
margin_four = 0.06  # 6%
margin_five = 0.05  # 5%

# New parameter for transport cost
transport_cost = 750  # Note: This value will come from a DB/admin backend later

# Adding new parameters for licence plate fee and RDW inspection
licence_plate_fee = 110  # Note: This value will come from a DB/admin backend later
rdw_inspection = 344  # Note: This value will come from a DB/admin backend later

# New parameter for unforeseen costs as a percentage
unforeseen_percentage = 0.01  # 1% - Note: This value will come from a DB/admin backend later


# Calculating nett price
nett_price = original_price / de_tax

# Defining range thresholds as parameters for margin selection
range_one = (0, 15000)  # Use margin_one
range_two = (15001, 30000)  # Use margin_two
range_three = (30001, 50000)  # Use margin_three
range_four = (50001, 100000)  # Use margin_four
range_five = (100001, float('inf'))  # Use margin_five

# Determining which margin to use based on original_price
if range_one[0] <= original_price <= range_one[1]:
    selected_margin = margin_one
elif range_two[0] <= original_price <= range_two[1]:
    selected_margin = margin_two
elif range_three[0] <= original_price <= range_three[1]:
    selected_margin = margin_three
elif range_four[0] <= original_price <= range_four[1]:
    selected_margin = margin_four
elif original_price >= range_five[0]:
    selected_margin = margin_five
else:
    selected_margin = margin_five  # In case original_price does not fit any defined range

# Calculating taxable price and dealer margin
dealer_margin = nett_price * selected_margin
taxable_price = nett_price + dealer_margin

# Calculating the taxed price
taxed_price = taxable_price * nl_tax

# Calculating de_vat and nl_vat
de_vat = original_price - nett_price
nl_vat = taxed_price - taxable_price

# Calculating the unforeseen cost
unforeseen_cost = nett_price * unforeseen_percentage

# Correcting the calculation for the final price using taxed_price
final_price = taxed_price + transport_cost + licence_plate_fee + rdw_inspection + bpm_rate + unforeseen_cost

# Print statements for testing
print(f"Original Price: {original_price}")
print(f"DE Tax Rate: {de_tax}")
print(f"NL Tax Rate: {nl_tax}")
print(f"DE VAT: {de_vat:.2f}")
print(f"NL VAT: {nl_vat:.2f}")
print(f"Nett Price: {nett_price:.2f}")
print(f"Selected Margin (%): {selected_margin * 100}")
print(f"Dealer Margin: {dealer_margin:.2f}")
print(f"Taxable Price: {taxable_price:.2f}")
print(f"Taxed Price: {taxed_price:.2f}")
print(f"Transport Cost: {transport_cost}")
print(f"Licence Plate Fee: {licence_plate_fee}")
print(f"RDW Inspection: {rdw_inspection}")
print(f"Unforeseen Percentage: {unforeseen_percentage * 100}%")
print(f"Unforeseen Cost: {unforeseen_cost:.2f}")
print(f"BPM Rate: {bpm_rate}")
print(f"Final Price: {final_price:.2f}")

