import os

import django

from TexBijl import settings
from TexBijl.settings import BASE_DIR
from datetime import date, datetime

from web_app.tool_box import calculate_bpm, calculate_final_price_with_tax, \
    calculate_monthly_payment_with_remaining_debt, recommended_cars

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "TexBijl.settings")
django.setup()
from mongo_utils import get_mongo_collection

filters = {}

filters['brand'] = 'Honda'


# collection = db['autoas']
# result = collection.find(filters)
# ids = []
# for d in result:
#     ids.append(d.get('unique_id'))
# print('Total Count', len(ids), ids)

# print(filters)


# def add_customer_to_mongo(first_name, last_name, email, phone, company, status):
#     collection = get_mongo_collection('customer_requests')
#
#     customer_data = {
#         'first_name': first_name,
#         'last_name': last_name,
#         'email': email,
#         'phone': phone,
#         'company': company,
#         'status': status,
#         'request_date_time': datetime.now()
#     }
#
#     result = collection.insert_one(customer_data)
#     return result.inserted_id
#
#
# add_customer_to_mongo(first_name='Test2', last_name='test2', email='test2@test.com', phone='14124141414',
#                       company='Test Company', status='pending')

# collection.create_index("unique_id", unique=True)

import pymongo
import uuid

# def generate_unique_id(collection):
#     """
#     Generate a unique identifier in the format XXXX-XXXX-XXXX
#     and ensure it does not exist in the collection.
#     """
#     while True:
#         # Generate a UUID, remove dashes, and take the first 12 characters
#         unique_id = str(uuid.uuid4()).replace('-', '')[:12]
#         # Format the string as XXXX-XXXX-XXXX
#         formatted_id = f"{unique_id[:4]}-{unique_id[4:8]}-{unique_id[8:]}"
#
#         # Check if the generated ID already exists in the collection
#         if collection.count_documents({"unique_id": formatted_id}) == 0:
#             return formatted_id

# MongoDB connection
# client = pymongo.MongoClient("mongodb://localhost:27017/")
# db = client["your_database"]
# collection = db["your_collection"]

# Batch size
# batch_size = 100
# skip = 2000
#
# while True:
#     print("In While")
#     documents = collection.find({"unique_id": {"$in": [None, ""]}}).skip(skip).limit(batch_size)
#     batch = list(documents)
#     if not batch:
#         break
#
#     for document in batch:
#         new_car_id = generate_unique_id(collection)
#         collection.update_one(
#             {"_id": document["_id"]},
#             {"$set": {"unique_id": new_car_id}}
#         )
#
#     skip += batch_size
#     print(skip)
#
# print("Updated all documents with null or missing unique_id values.")


# types = collection.distinct('energyconsumption.Fueltype')
# print(types)


# print(collection.distinct('model', filters))


# print(recommended_cars(limit=3, brand='Audi'))


collection = get_mongo_collection('autoas')
print(sorted(collection.distinct('Equipment.extras')))
