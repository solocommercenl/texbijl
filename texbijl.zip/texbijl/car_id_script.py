import pymongo
import uuid
from pymongo import UpdateOne


def generate_unique_id(collection):
    """
    Generate a unique identifier in the format XXXX-XXXX-XXXX
    and ensure it does not exist in the collection.
    """
    while True:
        unique_id = str(uuid.uuid4()).replace('-', '')[:12]
        formatted_id = f"{unique_id[:4]}-{unique_id[4:8]}-{unique_id[8:]}"
        if collection.count_documents({"unique_id": formatted_id}) == 0:
            return formatted_id


# MongoDB connection
client = pymongo.MongoClient("mongodb://65.21.253.114:27017/?directConnection=true")
db = client["autobase"]
collection = db["autoas"]

# Create a unique index on the unique_id field
collection.create_index("unique_id", unique=True)

# Batch size
batch_size = 10000
skip = 0

while True:
    print("Processing batch starting at skip:", skip)
    documents = collection.find({"unique_id": {"$in": [None, ""]}}).skip(skip).limit(batch_size)
    batch = list(documents)
    if not batch:
        break

    bulk_updates = []
    for document in batch:
        new_car_id = generate_unique_id(collection)
        bulk_updates.append(
            UpdateOne(
                {"_id": document["_id"]},
                {"$set": {"unique_id": new_car_id}}
            )
        )

    if bulk_updates:
        collection.bulk_write(bulk_updates)

    skip += batch_size
    print(f"Processed {skip} documents")

print("Updated all documents with null or missing unique_id values.")
