from django.urls import path, include
from rest_apis import views

urlpatterns = [
    path('filters/', views.Filters.as_view(), name='filters'),
    path('filters/get_model', views.GetModel.as_view(), name='api_get_model'),
    path('recommendations', views.Recommendations.as_view(), name='recommendations'),
    path('listings', views.Listings.as_view(), name='listings'),
    path('listings/<str:car_id>', views.ListingDetail.as_view(), name='listings_detail'),
    path('calulate_payment', views.CalculatePayment.as_view(), name='calulate_payment'),

    path('submit-form/', views.submit_form, name='submit_form'),
]
