import json
import re
from math import ceil
from TexBijl import settings
from datetime import datetime
from rest_framework import status
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from mongo_utils import get_mongo_collection
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt
from rest_apis.serializers import CalculatePaymentSerializer
from rest_apis.tool_box import get_input_values, recommended_cars, calculate_final_price_with_tax, \
    calculate_monthly_payment_with_remaining_debt




class Filters(APIView):

    def get(self, request):
        data = get_input_values()
        collection = get_mongo_collection('autoas')
        filters = {'listing_status': True,
                   'energyconsumption.emissions': {'$ne': '- (g/km)'},
                   'price': {'$gte': 5000, '$lte': 250000},
                   'Images': {'$ne': []},
                   'energyconsumption.Fueltype': {'$ne': 'others'}
                   }
        data['car_count'] = collection.count_documents(filters)
        return Response(data, status=status.HTTP_200_OK)


class GetModel(APIView):

    def get(self, request):
        brand = request.GET.get('brand', '')
        if not brand:
            return Response('Brand is required', status=status.HTTP_400_BAD_REQUEST)
        collection = get_mongo_collection('autoas')
        data = {'models': collection.distinct('model', {'brand': brand})}
        return Response(data, status=status.HTTP_200_OK)


class Recommendations(APIView):

    def get(self, request):
        brand = request.GET.get('brand', '')
        limit = int(request.GET.get('limit', 3))
        if not brand:
            return Response('Brand is required', status=status.HTTP_400_BAD_REQUEST)
        recommendations = recommended_cars(limit=limit, brand=brand)
        return Response(recommendations, status=status.HTTP_200_OK)


class Listings(APIView):
    def get(self, request):
        page_number = int(request.GET.get('page_number', 1))
        sort_filter = int(request.GET.get('sort_filter', 1))
        records_per_page = int(request.GET.get('records_per_page', 10))
        records_per_page = records_per_page  # Example number of records per page
        skip = (page_number - 1) * records_per_page
        filters = {'listing_status': True,
                   'energyconsumption.emissions': {'$ne': '- (g/km)'},
                   'price': {'$gte': 5000, '$lte': 250000},
                   'Images': {'$ne': []},
                   'energyconsumption.Fueltype': {'$ne': 'others'}}
        data = {}
        collection = get_mongo_collection('autoas')

        sort_options = {
            1: ("_id", 1),  # Oldest to newest
            2: ("_id", -1),  # Newest to oldest
            3: ("price", 1),  # Price low to high
            4: ("price", -1),  # Price high to low

        }
        print(request.query_params)
        sort_criteria = sort_options.get(sort_filter, ("_id", -1))
        for key, value in request.query_params.items():
            if key == 'price__gte':
                filters['price'] = {'$gte': int(value)}

            elif key == 'fuel_type':
                fuel_types = value.split(',')
                if fuel_types:
                    filters['$or'] = [{'energyconsumption.Fueltype': {'$regex': re.escape(fuel_type), '$options': 'i'}}
                                      for fuel_type in fuel_types]

            elif key == 'car_body':
                car_bodies = value.split(',')
                if car_bodies:
                    filters['Basicdata.Body'] = {'$in': car_bodies}

            elif key == 'price__lte':
                filters.setdefault('price', {}).update({'$lte': int(value)})
            elif key == 'year__gte':
                filters['registration_year'] = {'$gte': int(value)}

            elif key == 'year__lte':
                filters.setdefault('registration_year', {}).update({'$lte': int(value)})

            elif key == 'milage__gte':
                filters['milage'] = {'$gte': int(value)}
            elif key == 'milage__lte':
                filters.setdefault('milage', {}).update({'$lte': int(value)})

            elif key == 'brand':
                if value:
                    filters['brand'] = value
                    data['models'] = collection.distinct('model', {'brand': value})

            elif key == 'model':
                filters['model'] = value

            elif key == 'doors':
                doors = value.split(',')
                if doors:
                    filters['Basicdata.Doors'] = {'$in': doors}

            elif key == 'car_body':
                car_bodies = value.split(',')
                if car_bodies:
                    filters['Basicdata.Body'] = {'$in': car_bodies}

            elif key == 'extras':
                options = value.split(',')
                if options:
                    filters['Equipment.extras'] = {'$in': options}

            elif key == 'entertainmentAndMedia':
                options = value.split(',')
                if options:
                    filters['Equipment.entertainmentAndMedia'] = {'$in': options}
            elif key == 'safetyAndSecurity':
                options = value.split(',')
                if options:
                    filters['Equipment.safetyAndSecurity'] = {'$in': options}
            elif key == 'ComfortConvenience':
                options = value.split(',')
                if options:
                    filters['Equipment.ComfortConvenience'] = {'$in': options}
            else:
                pass
        total_count = collection.count_documents(filters)
        data['total_count'] = total_count
        if request.GET.get('listing', ''):
            projection = {'_id': 1, 'Unique_ID': 1, 'title': 1, 'price': 1, 'Basicdata.Type': 1,
                          'vehiclehistory.Mileage': 1, 'vehiclehistory.Firstregistration': 1, 'Basicdata.Body': 1,
                          'TechnicalData.Power': 1, 'TechnicalData.Gearbox': 1, 'energyconsumption.Fueltype': 1,
                          'energyconsumption.emissions': 1,
                          'Images': 1, 'brand': 1, 'model': 1, 'registration': 1, 'milage': 1, 'car_id': 1}

            documents = list(collection.find(filters, projection).sort([sort_criteria]).skip(skip).limit(
                records_per_page))

            for doc in documents:
                doc['_id'] = str(doc['_id'])
                images = doc.get('Images', [])
                if images:
                    doc['image_url'] = images[0]  # Extract the first image URL directly
                else:
                    doc['image_url'] = ''
                del doc['Images']
                try:
                    print(doc.get("Unique_ID"))
                    final_price = calculate_final_price_with_tax(doc)

                    down_payment = final_price * 0.1
                    desired_remaining_debt = final_price * 0.2
                    monthly_payment = calculate_monthly_payment_with_remaining_debt(final_price, down_payment,
                                                                                    annual_interest_rate=0.1,
                                                                                    loan_duration_months=72,
                                                                                    desired_remaining_debt=desired_remaining_debt)
                    print(monthly_payment, 'monthly_payment')
                    doc['price_including_tax'] = final_price
                    doc['monthly_payment'] = monthly_payment
                except Exception as e:
                    print(e)
            total_pages = ceil(total_count / records_per_page)
            prev_page = page_number - 1 if page_number > 1 else None
            next_page = page_number + 1 if page_number < total_pages else None
            # page_numbers = list(range(1, total_pages + 1))
            page_numbers = list(range(max(1, page_number - 5), min(total_pages + 1, page_number + 6)))

            data['current_page'] = page_number
            data['page_numbers'] = page_numbers
            data['prev_page'] = prev_page
            data['next_page'] = next_page
            data['total_pages'] = total_pages
            data['listing'] = documents
        # documents['Images'] = documents['Images'][:1]

        return Response(data)


def convert_object_id(doc):
    if '_id' in doc:
        doc['_id'] = str(doc['_id'])
    return doc


class ListingDetail(APIView):
    def get(self, request, car_id):
        try:
            collection = get_mongo_collection('autoas')
            car_detail = collection.find_one({'car_id': car_id, 'listing_status': True})

            if car_detail is None:
                return Response('Car not found', status=status.HTTP_404_NOT_FOUND)

            car_detail = convert_object_id(car_detail)  # Convert ObjectId to string

            final_price = calculate_final_price_with_tax(car_detail)
            down_payment = final_price * 0.1
            desired_remaining_debt = final_price * 0.2
            monthly_payment = calculate_monthly_payment_with_remaining_debt(final_price, down_payment,
                                                                            annual_interest_rate=0.1,
                                                                            loan_duration_months=72,
                                                                            desired_remaining_debt=desired_remaining_debt)
            car_images = car_detail.get('Images', [])  # Assuming car.Images contains a list of image URLs
            indexed_car_images = [(index, image_url) for index, image_url in enumerate(car_images)]
            data = {
                'car': car_detail,
                'indexed_car_images': indexed_car_images,
                'final_price': final_price,
                'monthly_payment': monthly_payment,
                'down_payment': int(down_payment),
                'desired_remaining_debt': int(desired_remaining_debt)
            }
            return Response(data, status=status.HTTP_200_OK)

        except Exception as e:
            print(e)
            return Response('Something went wrong please try again later', status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class CalculatePayment(APIView):

    def get(self, request):
        serializer = CalculatePaymentSerializer(data=request.GET)
        if serializer.is_valid():
            final_price = serializer.validated_data['final_price']
            down_payment = serializer.validated_data['down_payment']
            loan_duration_months = serializer.validated_data['loan_duration_months']
            desired_remaining_debt = serializer.validated_data['desired_remaining_debt']

            monthly_payment = calculate_monthly_payment_with_remaining_debt(
                final_price,
                down_payment,
                annual_interest_rate=0.1,
                loan_duration_months=loan_duration_months,
                desired_remaining_debt=desired_remaining_debt
            )

            data = {
                'down_payment': down_payment,
                'loan_duration_months': loan_duration_months,
                'desired_remaining_debt': desired_remaining_debt,
                'monthly_payment': monthly_payment,
            }
            return Response(data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@csrf_exempt
def submit_form(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        email_address = data.get('email', '')
        first_name = data.get('firstName', '')
        last_name = data.get('lastName', '')
        phone = data.get('phone', '')
        company = data.get('company', '')

        customer_deposit = data.get('deposit', '')
        customer_term = data.get('term', '')
        customer_monthlyAmount = data.get('monthlyAmount', '')
        customer_finalAmount = data.get('finalAmount', '')

        if not email_address and not first_name and not last_name and not phone:
            return JsonResponse(
                {"message": "Required fields are missing"})

        car_id = data.get('car_id')
        try:
            collection = get_mongo_collection('autoas')

            car_detail = collection.find_one({'car_id': car_id, 'listing_status': True})
            price_without_tax = car_detail['price']
            final_price = calculate_final_price_with_tax(car_detail)
            print('final_price :', final_price)
            down_payment = final_price * 0.1
            desired_remaining_debt = final_price * 0.2
            monthly_payment = calculate_monthly_payment_with_remaining_debt(final_price, down_payment,
                                                                            annual_interest_rate=0.1,
                                                                            loan_duration_months=72,
                                                                            desired_remaining_debt=desired_remaining_debt)

            data = {'model': car_detail.get('model', ''),
                    'brand': car_detail.get('brand', ''),
                    'first_name': first_name,
                    'last_name': last_name,
                    'phone': phone,
                    'company': company,

                    'price_with_tax': final_price,
                    'price_without_tax': price_without_tax,
                    'monthly_payment': monthly_payment,
                    'email': email_address,
                    'unique_id': car_id,
                    'product_url': car_detail.get('Product_URL', ''),

                    'customer_deposit': customer_deposit,
                    'customer_term': customer_term,
                    'customer_monthlyAmount': customer_monthlyAmount,
                    'customer_finalAmount': customer_finalAmount,

                    }
            message = render_to_string(
                'rest_apis/emails/request_email.html',
                data
            )
            try:
                customer_collection = get_mongo_collection('customer_requests')
                customer_data = {
                    'first_name': first_name,
                    'last_name': last_name,
                    'car_id': car_id,
                    'email': email_address,
                    'phone': phone,
                    'company': company,
                    'status': 'pending',
                    'customer_deposit': customer_deposit,
                    'customer_term': customer_term,
                    'customer_monthly_amount': customer_monthlyAmount,
                    'customer_final_amount': customer_finalAmount,
                    'request_date_time': datetime.now()
                }

                result = customer_collection.insert_one(customer_data)
            except Exception as e:
                pass
            subject = "New Offer is Submitted"
            email_from = settings.EMAIL_HOST_USER
            email = EmailMessage(subject, message, email_from, to=['info@texbijl.nl'],
                                 cc=['sbucommerce@gmail.com'], )
            # email = EmailMessage(subject, message, email_from, to=['saadmughal4646@gmail.com'])
            email.content_subtype = "html"
            email.send()
        except Exception as e:
            print(e)
        return JsonResponse({"message": "Form submitted successfully!", "email": email_address, "car_id": car_id})

    return JsonResponse({"error": "Invalid request method"}, status=400)