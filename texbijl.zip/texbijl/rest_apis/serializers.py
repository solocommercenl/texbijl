from rest_framework import serializers


class CalculatePaymentSerializer(serializers.Serializer):
    final_price = serializers.FloatField()
    down_payment = serializers.FloatField()
    loan_duration_months = serializers.IntegerField()
    desired_remaining_debt = serializers.FloatField()
