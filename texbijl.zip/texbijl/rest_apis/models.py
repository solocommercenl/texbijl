from django.db import models
from db_connection import db

# Create your models here.


data_collection = db['dbcollection']

from django.db import models

# Create your models here.
