import datetime
import re

from mongo_utils import get_mongo_collection

table_on_fuel_type = {
    'Gasoline': 'petroltax',
    'LPG': 'petroltax',
    'CNG': 'petroltax',
    'Electric/Gasoline': 'phevtax',
    'Diesel': 'dieseltax',
    'Electric/Diesel': 'phevtax',

}


def get_input_values():
    price_range_start = 10000
    price_range_end = 250000
    step = 10000

    collection = get_mongo_collection('autoas')
    data = {}
    today = datetime.datetime.today()
    data['brands'] = sorted(collection.distinct('brand'))
    data['car_body'] = sorted(collection.distinct('Basicdata.Body'))
    years = list(range(2018, today.year))
    data['years_from'] = years
    data['years_to'] = years[::-1]
    price_range = [5000] + list(range(price_range_start, price_range_end + 1, step))
    data['price_from'] = price_range
    data['price_to'] = price_range[::-1]

    fuel_types = collection.distinct('energyconsumption.Fueltype')

    data['fuel_types'] = [fuel_type for fuel_type in fuel_types if fuel_type and fuel_type.lower() != 'others']
    data['gearbox'] = [
        '',
        'Manual',
        'Automatic',
    ]
    data['doors_range'] = [
        1, 2, 3, 4, 5, 6, 7, 8, 9]

    data['extras'] = sorted(collection.distinct('Equipment.extras'))
    data['safetyAndSecurity'] = sorted(collection.distinct('Equipment.safetyAndSecurity'))
    data['entertainmentAndMedia'] = sorted(collection.distinct('Equipment.entertainmentAndMedia'))
    data['ComfortConvenience'] = sorted(collection.distinct('Equipment.ComfortConvenience'))

    return data


def get_age_in_months(registration_date):
    try:
        print(registration_date)
        given_date = datetime.datetime.strptime(registration_date, "%m/%Y")
        current_date = datetime.datetime.now()
        age_in_months = (current_date.year - given_date.year) * 12 + (current_date.month - given_date.month)
        print("Age in months:", age_in_months)
        return age_in_months
    except ValueError:
        print("Error: Invalid registration date format. Please provide date in MM/YYYY format.")
        return None


def get_discount(car_age):
    try:
        discount_price = 0
        collection = get_mongo_collection('bpm')
        pipeline = [{"$project": {"discountValue": f"$discount.{car_age}"}}]
        result = collection.aggregate(pipeline)
        for doc in result:
            print(doc["discountValue"])
            discount_price = doc["discountValue"]
        return discount_price
    except Exception as e:
        print(f"Error in getting discount: {e}")
        return None


def get_tax(fuel_type, c02_emission):
    try:
        print('c02_emission', c02_emission)
        table = table_on_fuel_type[fuel_type]
        tax_price = 0
        collection = get_mongo_collection('bpm')
        pipeline = [{"$project": {"TaxValue": f"${table}.{c02_emission}"}}]
        result = collection.aggregate(pipeline)
        for doc in result:
            print(doc["TaxValue"])
            tax_price = doc["TaxValue"]
        return tax_price
    except KeyError:
        print("Error: Fuel type not found in table.")
        return None
    except Exception as e:
        print(f"Error in getting tax: {e}")
        return None


def calculate_bpm(registration_date, fuel_type, c02_emission):
    car_age = get_age_in_months(registration_date)
    if car_age is None:
        return
    discount = get_discount(car_age)
    if discount is None:
        return
    tax = get_tax(fuel_type=fuel_type, c02_emission=c02_emission)
    if tax is None:
        return
    print(f'car age: {car_age}, discount: {discount}, tax : {tax}')
    discount_amount = tax * (discount / 100)
    discounted_price = tax - discount_amount
    print(discounted_price)
    return discounted_price


# get the age from the table and then check for discount price from discorunt table
# base of fuel type check in the table on the base of co2 to get tax
# then apply discount on that tax to get the final bpm


def calculate_final_price_with_tax(car):
    registration_date = car.get('registration', '')
    print('registration_date', registration_date)
    fuel_type = car.get('energyconsumption', {}).get('Fueltype', '')
    print(fuel_type)
    c02_emission = car.get('energyconsumption', {}).get('emissions', '')
    print(c02_emission)
    if fuel_type.lower() not in ['electric'] and c02_emission is not None:

        match = re.search(r'\b\d+\b', c02_emission)

        if match:
            value = int(match.group())  # Convert the matched value to an integer
            c02_emission = value
        else:
            c02_emission = None
        bpm = calculate_bpm(registration_date=registration_date, fuel_type=fuel_type,
                            c02_emission=c02_emission)
    else:
        bpm = 0

    original_price = car.get('price')

    # Adding bpm_rate parameter
    bpm_rate = bpm  # Note: This value will come from another function/script in the future
    print('bpm_rate', bpm_rate)
    # Tax rates
    de_tax = 1.19  # Tax rate for Germany
    nl_tax = 1.21  # Tax rate for the Netherlands

    # Updated margin values with specified percentages
    margin_one = 0.10  # 10%
    margin_two = 0.08  # 8%
    margin_three = 0.07  # 7%
    margin_four = 0.06  # 6%
    margin_five = 0.05  # 5%

    # New parameter for transport cost
    transport_cost = 750  # Note: This value will come from a DB/admin backend later

    # Adding new parameters for licence plate fee and RDW inspection
    licence_plate_fee = 110  # Note: This value will come from a DB/admin backend later
    rdw_inspection = 344  # Note: This value will come from a DB/admin backend later

    # New parameter for unforeseen costs as a percentage
    unforeseen_percentage = 0.01  # 1% - Note: This value will come from a DB/admin backend later

    # Calculating nett price
    nett_price = original_price / de_tax

    # Defining range thresholds as parameters for margin selection
    range_one = (0, 15000)  # Use margin_one
    range_two = (15001, 30000)  # Use margin_two
    range_three = (30001, 50000)  # Use margin_three
    range_four = (50001, 100000)  # Use margin_four
    range_five = (100001, float('inf'))  # Use margin_five

    # Determining which margin to use based on original_price
    if range_one[0] <= original_price <= range_one[1]:
        selected_margin = margin_one
    elif range_two[0] <= original_price <= range_two[1]:
        selected_margin = margin_two
    elif range_three[0] <= original_price <= range_three[1]:
        selected_margin = margin_three
    elif range_four[0] <= original_price <= range_four[1]:
        selected_margin = margin_four
    elif original_price >= range_five[0]:
        selected_margin = margin_five
    else:
        selected_margin = margin_five  # In case original_price does not fit any defined range

    # Calculating taxable price and dealer margin
    dealer_margin = nett_price * selected_margin
    taxable_price = nett_price + dealer_margin

    # Calculating the taxed price
    taxed_price = taxable_price * nl_tax

    # Calculating de_vat and nl_vat
    de_vat = original_price - nett_price
    nl_vat = taxed_price - taxable_price

    # Calculating the unforeseen cost
    unforeseen_cost = nett_price * unforeseen_percentage

    # Correcting the calculation for the final price using taxed_price
    final_price = taxed_price + transport_cost + licence_plate_fee + rdw_inspection + bpm_rate + unforeseen_cost

    return int(final_price)


def calculate_monthly_payment_with_remaining_debt(final_price, down_payment, annual_interest_rate, loan_duration_months,
                                                  desired_remaining_debt):
    """
    Calculates the monthly payment for a financial lease, aiming for a specific remaining debt at the end of the loan term.

    Parameters:
    - final_price: The price we get from the oter calculations and wgich is shown on website
    - down_payment: The initial payment made upfront, reducing the financed amount.
    - annual_interest_rate: The annual interest rate as a decimal (e.g., 10% as 0.1).
    - loan_duration_months: The total number of months for the loan.
    - desired_remaining_debt: The desired remaining debt at the end of the loan term.

    Returns:
    The monthly payment amount.
    """
    # Principal is now calculated as final_price minus down_payment
    principal = final_price - down_payment

    # Convert annual interest rate to monthly
    monthly_interest_rate = annual_interest_rate / 12

    # First, calculate the present value of the desired remaining debt at the end of the loan term
    present_value_of_remaining_debt = desired_remaining_debt / ((1 + monthly_interest_rate) ** loan_duration_months)

    # Adjust the principal by subtracting the present value of the desired remaining debt
    adjusted_principal = principal - present_value_of_remaining_debt

    # Calculate monthly payment on the adjusted principal
    monthly_payment = adjusted_principal * (
            monthly_interest_rate / (1 - (1 + monthly_interest_rate) ** (-loan_duration_months)))

    return int(monthly_payment)


def recommended_cars(limit, brand=None):
    print('brand is', brand)
    collection = get_mongo_collection('autoas')

    filters = {'listing_status': True,
               'energyconsumption.emissions': {'$ne': '- (g/km)'},
               'price': {'$gte': 20000, '$lte': 400000},
               'Images': {'$ne': []},
               'energyconsumption.Fueltype': {'$ne': 'others'}}
    if brand:
        filters['brand'] = brand

    projection = {
        '_id': 1, 'Unique_ID': 1, 'title': 1, 'price': 1, 'Basicdata.Type': 1,
        'vehiclehistory.Mileage': 1, 'vehiclehistory.Firstregistration': 1, 'Basicdata.Body': 1,
        'TechnicalData.Power': 1, 'TechnicalData.Gearbox': 1, 'energyconsumption.Fueltype': 1,
        'energyconsumption.emissions': 1, 'Images': 1, 'brand': 1, 'model': 1, 'registration': 1, 'car_id': 1,
    }

    pipeline = [
        {"$match": filters},
        {"$sample": {"size": limit}},
        {"$project": projection}
    ]

    documents = list(collection.aggregate(pipeline))

    for doc in documents:
        doc['_id'] = str(doc['_id'])
        images = doc.get('Images', [])
        doc['image_url'] = images[0] if images else ''
        del doc['Images']

        try:
            print(doc.get("Unique_ID"))
            print(doc.get("car_id"))
            final_price = calculate_final_price_with_tax(doc)

            down_payment = final_price * 0.1
            desired_remaining_debt = final_price * 0.2
            monthly_payment = calculate_monthly_payment_with_remaining_debt(
                final_price, down_payment,
                annual_interest_rate=0.1,
                loan_duration_months=72,
                desired_remaining_debt=desired_remaining_debt
            )
            print(monthly_payment, 'monthly_payment')
            doc['price_including_tax'] = final_price
            doc['monthly_payment'] = monthly_payment
        except Exception as e:
            print(e)

    return documents
