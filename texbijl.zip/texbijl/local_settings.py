SECRET_KEY =  'django-insecure-84-f72y&*3wo^w@ge_b6_cd072d(*oymuwx&_jio+(udd$^)@o'


ALLOWED_HOSTS = ['*']

#Unique Filter
UNIQUE_KEYS = ['model', 'gearbox', 'power', 'milage']


# This is the filter we are using to filter out the results

DEFAULT_FILTERS = {'listing_status': True,
                   'energyconsumption.emissions': {'$ne': '- (g/km)'},
                   'price': {'$gte': 5000, '$lte': 250000},
                   'Images': {'$ne': []},
                   'energyconsumption.Fueltype': {'$ne': 'others'}}



# MONGODB_DEBUG = {
#     'host': '65.21.253.114',
#     'port': 27017,
#     'db_name': 'autobase',~
# }

MONGODB = {
    'host': os.getenv('MONGODB_HOST', '10.0.0.4'),
    'port': int(os.getenv('MONGODB_PORT', 27017)),
    'db_name': os.getenv('MONGODB_DB_NAME', 'autobase'),
    'username': os.getenv('MONGODB_USER', 'AutoBaseAdmin'),  # Gebruikersnaam
    'password': os.getenv('MONGODB_PASSWORD', 'KU2dwF2j2NUWjZMXRPRv'),  # Wachtwoord
    'auth_source': os.getenv('MONGODB_AUTH_SOURCE', 'admin'),  # Authenticatiebron
}


# Email Setup

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.mailersend.net'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_USE_SSL = False
EMAIL_HOST_USER = 'MS_YuvRDY@texbijl.nl'
EMAIL_HOST_PASSWORD = 'cSEjGz1LbXljP91T'
