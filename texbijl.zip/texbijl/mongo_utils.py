from pymongo import MongoClient
from django.conf import settings


def get_mongo_client():
    mongo_settings = settings.MONGODB

    # Verbind met MongoDB via authenticatie
    uri = f"mongodb://{mongo_settings['username']}:{mongo_settings['password']}@" \
          f"{mongo_settings['host']}:{mongo_settings['port']}/" \
          f"?authSource={mongo_settings['auth_source']}"  # Voeg authSource toe
    
    # Maak een client met de URI
    client = MongoClient(uri)
    return client


def get_mongo_collection(collection_name):
    client = get_mongo_client()
    db_name = settings.MONGODB['db_name']
    db = client[db_name]
    return db[collection_name]